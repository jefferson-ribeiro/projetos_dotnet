﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using cadastro.Models;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using System.Text;
using Microsoft.Net.Http.Headers;
using System.IO;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;

namespace cadastro.Controllers
{
  public class ClientesController : Controller
  {
    [Route("/cadastro")]
    public IActionResult Cadastro()
    {
      return View();
    }

    [Route("/cadastrar")]
    public IActionResult Cadastrar(String nome, String telefone, String email)
    {
      //Criar a instancia da classe
      Cliente cliente = new Cliente();

      cliente.Nome = nome;
      cliente.Telefone = telefone;
      cliente.Email = email;

      Program.Clientes.Add(cliente);

      string json = JsonConvert.SerializeObject(Program.Clientes);
      System.IO.File.WriteAllText(@"D:\Users\Jefferson\clientes.txt", json);

      //Criar a instancia do objeto cliente e preencher as propriedades
      return Redirect("/");
    }
    [Route("/lista")]
    public IActionResult Lista()
    {
      ViewBag.Clientes = Program.Clientes;
      return View();
    }
  }
}