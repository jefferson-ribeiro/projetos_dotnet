using System;
using Microsoft.EntityFrameworkCore;

namespace cadastro.Models
{
  public class ContextoDb : DbContext
  {
    public ContextoDb(DbContextOptions<ContextoDb> options) : base(options) { }

    public DbSet<Cliente> Clientes { get; set; }
  }

}
